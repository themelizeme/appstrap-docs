Jekyll build command: 

bundle exec jekyll serve

OR
 
bundle exec jekyll serve --livereload --incremental

Dist build command:
gulp




export PATH=$HOME/.gem/ruby/2.6.3p62/bin:$PATH

